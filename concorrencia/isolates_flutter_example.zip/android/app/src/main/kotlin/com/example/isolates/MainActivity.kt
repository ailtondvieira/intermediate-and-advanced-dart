package com.example.isolates

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
